package com.restaurant.qrcode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QrcodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
