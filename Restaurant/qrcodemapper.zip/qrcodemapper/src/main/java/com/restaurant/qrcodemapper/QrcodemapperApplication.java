package com.restaurant.qrcodemapper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QrcodemapperApplication {

	public static void main(String[] args) {
		SpringApplication.run(QrcodemapperApplication.class, args);
	}

}
