package com.restaurant.qrcodemapper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QrcodemapperApplicationTests {

	@Test
	void contextLoads() {
	}

}
